This directory contains submissions from Damien Touraine that implements a GTK interface that includes mimicking a tracker, several buttons, and analogs.  This is like the Qt interface, in that it provides a server that you can design using a GUI.

